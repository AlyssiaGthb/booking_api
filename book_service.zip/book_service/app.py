from flask import Flask, request, jsonify
from models import Booking
from database import db_session
from datetime import datetime
import uuid
import os
from dotenv import load_dotenv

load_dotenv()

app=Flask(__name__)

@app.route('/bookings/create', methods=['POST'])
def create_booking():
    try:
        data=request.get_json()
        pickup_location=data.get('pickup_location')
        dropoff_location=data.get('dropoff_location')
        departure_date=data.get('departure_date')
        departure_time=data.get('departure_time')

        if not departure_date or not departure_time:
            return jsonify({"error": "departure_date and departure_time are required"}), 400


        departure_date = datetime.strptime(departure_date, '%Y-%m-%d').date() 
        departure_time = datetime.strptime(departure_time, '%H:%M:%S').time()

        booking_token=str(uuid.uuid4())

        booking = Booking(pickup_location=pickup_location,dropoff_location=dropoff_location,departure_date=departure_date,departure_time=departure_time,token=booking_token)

        db_session.add(booking)
        db_session.commit()
        
        return jsonify ({"message":"Booking registered successfully",
                         "booking_token":booking_token}),201
    except Exception as e:
        return jsonify({"error":str(e)})
    



@app.route('/bookings/cancel/<string:booking_token>',methods=['DELETE'])
def cancel_booking(booking_token):
    try:
        booking = db_session.query(Booking).filter(Booking.token==booking_token).first()

        if not booking:
            return jsonify ({"error":"Booking with the provided token not found"}),404
        
        db_session.delete(booking)
        db_session.commit()

        return jsonify({"message":f"Booking with token {booking_token} has been canceled"}),200
    
    except Exception as e:
        return jsonify({"error": str(e)}),500



if __name__=='__main__':
    app.run(debug=True,port=5002)
        
        

