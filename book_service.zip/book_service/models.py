from sqlalchemy import Column, Integer, String, Float, Time, Date, ForeignKey
import uuid
from database import Base

class Booking(Base):
    __tablename__='bookings'

    id = Column(Integer, primary_key=True, autoincrement=True)
    pickup_location = Column(String(255), nullable=False)  
    dropoff_location = Column(String(255), nullable=False)  
    departure_date = Column(Date, nullable=False)  
    departure_time = Column(Time, nullable=False)
    token = Column(String(36), unique=True, default=str(uuid.uuid4())) 


def __repr__(self):
    return f"<Booking(id={self.id}, price={self.price}, status={self.status})>"

